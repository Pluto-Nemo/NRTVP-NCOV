## :warning: Custom Shaders documentation has moved! :warning

This documentation now lives in
[`Documentation/CustomShaderGuide`](../../../../Documentation/CustomShaderGuide/README.md)
